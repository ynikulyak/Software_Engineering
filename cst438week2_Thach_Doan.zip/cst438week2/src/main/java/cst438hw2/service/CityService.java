package cst438hw2.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cst438hw2.domain.*;

@Service
public class CityService {
	
	@Autowired
	private CityRepository cityRepository;
	
	@Autowired
	private CountryRepository countryRepository;
	
	@Autowired
	private WeatherService weatherService;
	
	
	
	public CityService(CityRepository cityRepository, CountryRepository countryRepository,
			WeatherService weatherService) {
		super();
		this.cityRepository = cityRepository;
		this.countryRepository = countryRepository;
		this.weatherService = weatherService;
	}



	public CityInfo getCityInfo(String cityName) {
	//declare variable to use
		 int index = 0;
		 double temp = 0;
		List<City> myCity = cityRepository.findByName(cityName);
		City city = new City(myCity.get(index).getId(), myCity.get(index).getName(),
				myCity.get(index).getCountryCode(),
						myCity.get(index).getDistrict(),
						myCity.get(index).getPopulation());
		//calling country from country reposoitory
		Country myCountry = countryRepository.findByCode(city.getCountryCode());
		//get time and weather
		TempAndTime myTempAndTime = weatherService.getTempAndTime(cityName);
		//converting long number in seconds to hour
		Long s = myTempAndTime.time % 60;
		long m = (myTempAndTime.time / 60) % 60;
		long h = (myTempAndTime.time /(60 * 60) % 24);
		String strTime = String.format("%d:%02d:%02d", h,m,s);
		CityInfo cityInfo = new CityInfo(city, myCountry.getName(), temp, strTime);
		return cityInfo; 
	}
	
}
