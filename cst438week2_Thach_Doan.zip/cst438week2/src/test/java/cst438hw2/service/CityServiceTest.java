package cst438hw2.service;
 

import org.mockito.BDDMockito.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.BDDMockito.given;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.mockito.ArgumentMatchers.anyString;

import cst438hw2.domain.*;
 
@SpringBootTest
public class CityServiceTest {

	@MockBean
	private WeatherService weatherService;
	
	@Autowired
	private CityService cityService;
	
	@MockBean
	private CityRepository cityRepository;
	
	@MockBean
	private CountryRepository countryRepository;

	
	@Test
	public void contextLoads() {
	}


	@Test
	public void testCityFound() throws Exception {
		double temp = 63;
		//declare our City and country into our data
		City testCity = new City (3817, "Denver", "USA", "Colorado", 554636);
		CityInfo testCityInfo = new CityInfo(testCity, "USA", temp, "1600");
		
		//given(cityRepository.findByName("Denver")).willReturn((List<City>) testCity);
		//given(weatherService.getTempAndTime("Denver")).willReturn(new TempAndTime(70, 1500, 1600));
		
		//testing to see if "Denver" is on list
		assertEquals("Denver", testCity.getName());
		//test for temp to equal 63 that we apply to
		assertThat(testCityInfo.getTemp()).isEqualTo(63);
	}
	
	@Test 
	public void  testCityNotFound() {
		
		double temp = 63;
		City testCity = new City (3817, "Denver", "USA", "Colorado", 554636);
		CityInfo testCityInfo = new CityInfo(testCity, "USA", temp, "1600");
		//testing for city not found run will have one failure
		assertEquals("Miami", testCity.getName());
		
	}
	
	@Test 
	public void  testCityMultiple() {
		double temp = 63;
		City testCity = new City (3817, "Denver", "USA", "Colorado", 554636);
		CityInfo testCityInfo = new CityInfo(testCity, "USA", temp, "1600");
		//testing for city not found run will have one failure
		assertEquals("Los Angelas", testCity.getName());
		// TODO 
		
	}

}
