package cst438hw2.service;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cst438hw2.domain.*;

@Service
public class CityService {
   
   private static final Logger log = LoggerFactory.getLogger(CityService.class);

   @Autowired
   private CityRepository cityRepository;

   @Autowired
   private CountryRepository countryRepository;

   @Autowired
   private WeatherService weatherService;

   public Optional<CityInfo> getCityInfo(String cityName) {
      
      List<City> cities = cityRepository.findByName(cityName);
      Optional<City> cityOptional = cities.stream().findFirst();
      if (!cityOptional.isPresent()) {
         return Optional.empty();
      }
      
      City c = cityOptional.get();
      
      Optional<Country> countryOptional = countryRepository.findByCode((c.getCountryCode()));
      if(!countryOptional.isPresent()) {
         log.warn("Country for {} city was not found", cityName);
         return Optional.empty();
      }
      
      Country country = countryOptional.get();
      
      String countryName = country.getName();
      Optional<TempAndTime> tempAndTimeOptional = weatherService.getTempAndTime(cityName);
      if(!tempAndTimeOptional.isPresent()) {
         log.warn("Weather for {} city was not found", cityName);
         return Optional.empty();
      }
      
      TempAndTime tempAndTime = tempAndTimeOptional.get();
      
      double temperature = tempAndTime.temp;
      temperature = Math.round((temperature - 273.15) * 9.0/5.0 + 32.0);
      
      int timezone = tempAndTime.timezone;
      timezone = timezone/ 3600;
      
      long t = tempAndTime.time;
      
      LocalDateTime localDateTime = LocalDateTime.ofEpochSecond(t, 0, ZoneOffset.ofHours(timezone));
      String time = localDateTime.format(DateTimeFormatter.ofPattern("h:mm a"));
      
      return Optional.of(new CityInfo(c.getId(), c.getName(), c.getCountryCode(), countryName, 
            c.getDistrict(), c.getPopulation(), temperature, time));  
   }
}
