package cst438hw2.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import cst438hw2.domain.*;
import cst438hw2.service.CityService;
/*
 * Controller to get cityInfo object that would be used by city.html 
 */
@Controller
public class CityController {

   @Autowired
   private CityService cityService;

   @GetMapping("/cities/{city}")
   public String getWeather(@PathVariable("city") String cityName, Model model) {
      
      Optional<CityInfo> cityInfo = cityService.getCityInfo(cityName);
      //if city would not found, city.html return 404 status
      if (!cityInfo.isPresent()) {
         model.addAttribute("notFound", true);
      } else {
         model.addAttribute("notFound", false);
         model.addAttribute("cityInfo", cityInfo.get());
      }
      return "city"; //return city.html with the city info
   }

}